<?php
session_start();
require_once "conexao.php";
require '../Repositorio/LivroRepositorio.php';
require '../Modelo/Livro.php';
// ...

//$codigo = rand(0, 100000);
$LivroRepositorio = new LivroRepositorio($conn);

if (isset($_POST['editar'])){
    $livro = new Livro($_POST['id'], 
    $_POST['nome'], $_POST['autor'], $_POST['preco'],$_POST['descricao']);

    //se a imagem foi carregada
    if (isset($_FILES['imagem']['name']) && ($_FILES['imagem']['error'] == 0)){
        $testeImagem = true;
        $livro->setImagem(uniqid() . $_FILES['imagem']['name']);
        move_uploaded_file($_FILES['imagem']['tmp_name'], $livro->getImagemDiretorio());
    }elseif ($_FILES['imagem']['error'] == UPLOAD_ERR_NO_FILE){
      $livro->setImagem('');
    }

  
    $imagem = $_FILES['imagem']['name'];
    $imagemError = $_FILES['imagem']['error'];
    
    $LivroRepositorio->atualizarLivro($livro);
  //  header("Location: ../visao/admin.php?codedit=$codigo");
  
    echo "<form id='redirectForm' action='../admin.php' method='POST'>";
    echo "<input type='hidden' name='id' value='{$_POST['id']}'>";
    echo "<input type='hidden' name='autor' value='{$_POST['autor']}'>";
    echo "<input type='hidden' name='nome' value='{$_POST['nome']}'>";
    echo "<input type='hidden' name='descricao' value='{$_POST['descricao']}'>";
    echo "<input type='hidden' name='preco' value='{$_POST['preco']}'>";
    echo "</form>";
    echo "<script>document.getElementById('redirectForm').submit();</script>";



}